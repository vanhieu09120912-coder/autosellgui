package com.autosellgui;

import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class AutoSellScreen extends Screen {
    private static final int CELL = 20, COLS = 15, GRID_Y = 76, MAX_THRESHOLD = 1152;

    private final Screen parent;
    private final AutoSellConfig cfg = AutoSellConfig.get();
    private final List<Item> shown = new ArrayList<>();
    private TextFieldWidget search;
    private int gridX, rows, scroll;

    public AutoSellScreen(Screen parent) {
        super(Text.literal("AutoSellGUI"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int cx = width / 2;
        gridX = cx - COLS * CELL / 2;
        rows = Math.max(1, (height - GRID_Y - 34) / CELL);

        addDrawableChild(ButtonWidget.builder(toggleText(), b -> {
            cfg.enabled = !cfg.enabled;
            b.setMessage(toggleText());
            cfg.save();
        }).dimensions(cx - 155, 22, 150, 20).build());

        addDrawableChild(new ThresholdSlider(cx + 5, 22, 150, 20));

        search = new TextFieldWidget(textRenderer, cx - 155, 48, 150, 20, Text.literal("Tìm item"));
        search.setChangedListener(s -> refilter());
        addDrawableChild(search);

        addDrawableChild(ButtonWidget.builder(Text.literal("+ Tay cầm"), b -> {
            if (client != null && client.player != null) {
                ItemStack held = client.player.getMainHandStack();
                if (!held.isEmpty()) { cfg.items.add(AutoSellConfig.idOf(held.getItem())); cfg.save(); }
            }
        }).dimensions(cx + 5, 48, 73, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Xóa hết"), b -> {
            cfg.items.clear();
            cfg.save();
        }).dimensions(cx + 82, 48, 73, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Xong"), b -> close())
                .dimensions(cx - 50, height - 26, 100, 20).build());

        refilter();
    }

    private Text toggleText() {
        return Text.literal("AutoSell: " + (cfg.enabled ? "BẬT" : "TẮT"));
    }

    /** Item đang có trong túi đồ được đưa lên đầu danh sách. */
    private void refilter() {
        String q = search == null ? "" : search.getText().toLowerCase().trim();
        Set<Item> inv = new HashSet<>();
        if (client != null && client.player != null) {
            for (int i = 0; i < 36; i++) {
                ItemStack s = client.player.getInventory().getStack(i);
                if (!s.isEmpty()) inv.add(s.getItem());
            }
        }
        List<Item> first = new ArrayList<>(), rest = new ArrayList<>();
        for (Item it : Registries.ITEM) {
            if (it == Items.AIR) continue;
            boolean match = q.isEmpty()
                    || Registries.ITEM.getId(it).getPath().contains(q)
                    || nameOf(it).toLowerCase().contains(q);
            if (!match) continue;
            (inv.contains(it) ? first : rest).add(it);
        }
        shown.clear();
        shown.addAll(first);
        shown.addAll(rest);
        scroll = 0;
    }

    private static String nameOf(Item item) {
        return new ItemStack(item).getName().getString();
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        // Screen.render đã tự vẽ nền, không gọi renderBackground lần nữa
        super.render(ctx, mx, my, delta);
        ctx.drawCenteredTextWithShadow(textRenderer, "AutoSellGUI", width / 2, 8, 0xFFFFFFFF);

        Item hovered = null;
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < COLS; c++) {
                int idx = (scroll + r) * COLS + c;
                if (idx >= shown.size()) continue;
                Item it = shown.get(idx);
                int x = gridX + c * CELL, y = GRID_Y + r * CELL;
                boolean sel = cfg.items.contains(AutoSellConfig.idOf(it));
                ctx.fill(x, y, x + CELL - 1, y + CELL - 1, sel ? 0xAA00CC00 : 0x55000000);
                ctx.drawItem(new ItemStack(it), x + 2, y + 2);
                if (mx >= x && mx < x + CELL && my >= y && my < y + CELL) hovered = it;
            }
        }
        ctx.drawTextWithShadow(textRenderer, "Đã chọn: " + cfg.items.size(), gridX, height - 20, 0xFFAAAAAA);
        if (hovered != null) {
            ctx.drawCenteredTextWithShadow(textRenderer, nameOf(hovered), width / 2, 66, 0xFFFFFF55);
        }
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        if (super.mouseClicked(click, doubled)) return true;
        double mx = click.x(), my = click.y();
        if (click.button() == 0 && mx >= gridX && my >= GRID_Y) {
            int c = (int) ((mx - gridX) / CELL), r = (int) ((my - GRID_Y) / CELL);
            int idx = (scroll + r) * COLS + c;
            if (c < COLS && r < rows && idx < shown.size()) {
                String id = AutoSellConfig.idOf(shown.get(idx));
                if (!cfg.items.remove(id)) cfg.items.add(id);
                cfg.save();
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double horizontal, double vertical) {
        int total = (shown.size() + COLS - 1) / COLS;
        int max = Math.max(0, total - rows);
        scroll = Math.max(0, Math.min(max, scroll - (int) Math.signum(vertical)));
        return true;
    }

    @Override
    public void removed() {
        cfg.save();
    }

    @Override
    public void close() {
        if (client != null) client.setScreen(parent);
    }

    private class ThresholdSlider extends SliderWidget {
        ThresholdSlider(int x, int y, int w, int h) {
            super(x, y, w, h, Text.empty(), (AutoSellConfig.get().threshold - 1) / (double) (MAX_THRESHOLD - 1));
            updateMessage();
        }

        private int val() {
            return 1 + (int) Math.round(value * (MAX_THRESHOLD - 1));
        }

        @Override
        protected void updateMessage() {
            setMessage(Text.literal("Bán khi ≥ " + val() + " item"));
        }

        @Override
        protected void applyValue() {
            cfg.threshold = val();
        }
    }
}
