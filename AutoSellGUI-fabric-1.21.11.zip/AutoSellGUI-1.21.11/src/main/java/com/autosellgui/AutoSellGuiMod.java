package com.autosellgui;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class AutoSellGuiMod implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        AutoSellConfig.load();

        KeyBinding.Category category = KeyBinding.Category.create(Identifier.of("autosellgui", "main"));
        KeyBinding openKey = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.autosellgui.open", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_K, category));
        KeyBinding toggleKey = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.autosellgui.toggle", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_G, category));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (openKey.wasPressed()) {
                mc.setScreen(new AutoSellScreen(null));
            }
            while (toggleKey.wasPressed()) {
                AutoSellConfig cfg = AutoSellConfig.get();
                cfg.enabled = !cfg.enabled;
                cfg.save();
                if (mc.player != null) {
                    mc.player.sendMessage(Text.literal("AutoSell: " + (cfg.enabled ? "BẬT" : "TẮT")), true);
                }
            }
            AutoSellHandler.tick(mc);
        });
    }
}
