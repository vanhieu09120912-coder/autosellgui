package com.autosellgui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.SlotActionType;

import java.util.HashMap;
import java.util.Map;

public final class AutoSellHandler {
    private enum State { IDLE, WAIT_SCREEN, MOVING, CLOSING }

    private static State state = State.IDLE;
    private static int timer = 0;
    private static int cooldown = 0;
    private static final Map<Integer, Integer> attempts = new HashMap<>();

    private AutoSellHandler() {}

    public static void tick(MinecraftClient mc) {
        AutoSellConfig cfg = AutoSellConfig.get();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.interactionManager == null || !cfg.enabled) {
            state = State.IDLE;
            return;
        }

        switch (state) {
            case IDLE -> {
                if (cooldown > 0) { cooldown--; return; }
                if (mc.currentScreen != null) return;
                if (count(p, cfg) >= cfg.threshold) {
                    String cmd = cfg.command.startsWith("/") ? cfg.command.substring(1) : cfg.command;
                    p.networkHandler.sendChatCommand(cmd);
                    state = State.WAIT_SCREEN;
                    timer = 0;
                }
            }
            case WAIT_SCREEN -> {
                timer++;
                if (mc.currentScreen instanceof HandledScreen<?> && p.currentScreenHandler != p.playerScreenHandler) {
                    state = State.MOVING;
                    timer = 0;
                    attempts.clear();
                } else if (timer > 60) {
                    finish(cfg); // lệnh không mở được GUI
                }
            }
            case MOVING -> {
                ScreenHandler h = p.currentScreenHandler;
                if (h == p.playerScreenHandler) { finish(cfg); return; }
                if (++timer < cfg.clickDelay) return;
                timer = 0;

                // 36 slot cuối của GUI luôn là túi đồ người chơi (27 + 9 hotbar)
                int size = h.slots.size();
                int next = -1;
                if (size > 36) {
                    for (int i = size - 36; i < size; i++) {
                        if (attempts.getOrDefault(i, 0) >= 3) continue;
                        if (cfg.isSelected(h.slots.get(i).getStack())) { next = i; break; }
                    }
                }
                if (next == -1) {
                    state = State.CLOSING;
                    timer = 0;
                    return;
                }
                attempts.merge(next, 1, Integer::sum);
                mc.interactionManager.clickSlot(h.syncId, next, 0, SlotActionType.QUICK_MOVE, p);
            }
            case CLOSING -> {
                if (++timer >= cfg.clickDelay + 2) {
                    p.closeHandledScreen();
                    finish(cfg);
                }
            }
        }
    }

    private static int count(ClientPlayerEntity p, AutoSellConfig cfg) {
        int n = 0;
        for (int i = 0; i < 36; i++) {
            ItemStack s = p.getInventory().getStack(i);
            if (cfg.isSelected(s)) n += s.getCount();
        }
        return n;
    }

    private static void finish(AutoSellConfig cfg) {
        state = State.IDLE;
        cooldown = cfg.cooldownTicks;
        attempts.clear();
    }
}
