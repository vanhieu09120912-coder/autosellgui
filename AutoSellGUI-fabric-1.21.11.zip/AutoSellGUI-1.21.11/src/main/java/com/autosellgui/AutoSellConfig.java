package com.autosellgui;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashSet;
import java.util.Set;

public class AutoSellConfig {
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("autosellgui.json");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static AutoSellConfig instance;

    public boolean enabled = false;
    public int threshold = 64;        // đủ bao nhiêu item đã chọn thì bán
    public String command = "autosellgui";
    public int clickDelay = 3;        // tick giữa mỗi lần chuyển item
    public int cooldownTicks = 100;   // nghỉ sau mỗi lần bán
    public Set<String> items = new LinkedHashSet<>();

    public static AutoSellConfig get() {
        if (instance == null) load();
        return instance;
    }

    public static void load() {
        try {
            if (Files.exists(FILE)) instance = GSON.fromJson(Files.readString(FILE), AutoSellConfig.class);
        } catch (Exception ignored) {}
        if (instance == null) instance = new AutoSellConfig();
        if (instance.items == null) instance.items = new LinkedHashSet<>();
    }

    public void save() {
        try {
            Files.writeString(FILE, GSON.toJson(this));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static String idOf(net.minecraft.item.Item item) {
        return Registries.ITEM.getId(item).toString();
    }

    public boolean isSelected(ItemStack s) {
        return !s.isEmpty() && items.contains(idOf(s.getItem()));
    }
}
